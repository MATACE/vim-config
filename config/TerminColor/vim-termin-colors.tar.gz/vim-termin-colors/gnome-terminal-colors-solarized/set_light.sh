#!/usr/bin/env bash

dir=`dirname "$0"`
source $dir/src/set_theme_default_profile.sh light $*
