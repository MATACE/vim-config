# Official light solarized colorscheme

http://ethanschoonover.com/solarized
